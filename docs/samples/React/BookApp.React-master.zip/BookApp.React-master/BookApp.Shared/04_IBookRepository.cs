﻿namespace BookApp.Shared
{
    /// <summary>
    /// [4] Repository Interface, Provider Interface
    /// </summary>
    public interface IBookRepository : IBookCrudRepository<Book>
    {
        // 
    }
}
