import React from 'react'

const MyComponent = () => {
    return <h1>컴포넌트</h1>;
};

export default MyComponent;

