﻿import React, { Component } from 'react';

export class BooksIndex extends Component {
    render() {
        return <div><h1>책 리스트</h1></div>
    }
}
