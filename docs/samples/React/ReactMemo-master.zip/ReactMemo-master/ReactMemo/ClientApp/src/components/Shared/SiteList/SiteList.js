import React, { Component } from "react";

export class SiteList extends Component {
    render() {
        return (
            <ul>
                <li>Azure</li>
                <li>Bootstrap</li>
                <li>C#</li>
                <li>React</li>
            </ul>
        );
    }
}
