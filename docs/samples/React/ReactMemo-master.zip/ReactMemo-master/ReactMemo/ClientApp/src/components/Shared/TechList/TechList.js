import React, { Component } from "react";

export class TechList extends Component {
    render() {
        return (
            <ul>
                <li>Azure</li>
                <li>Bootstrap</li>
                <li>C#</li>
                <li>React</li>
            </ul>
        );
    }
}
