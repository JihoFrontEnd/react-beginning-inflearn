﻿import React, { Component } from 'react';

export class BooksCreate extends Component {
    render() {
        return <h1>Create</h1>; 
    }
}
